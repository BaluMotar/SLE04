# SLE-3: Architectural Design (Full C4 Model)
**Course:** 02AML204 – Introduction to Artificial Intelligence
PRN: ____________  Name: ____________  Division: A / B  Date: ____________
GitHub link: https://github.com/<your-username>/maze-solver-c4

## 1. System Title & Short Description
**Maze Solver System (BFS / DFS / A\*).** It reads a maze from a text file and finds a path from
the Start cell to the Goal cell. The user chooses an algorithm: BFS, DFS or A*. The system prints the
path, its length and the number of nodes expanded, so the algorithms can be compared. It applies the
search topics from the course (state space, frontier, heuristics) to a simple grid problem.

## 2. Context Diagram (Level 1)
[Insert docs/diagrams/c1_context.png – redrawn by you]
The User gives a maze file and chooses an algorithm. The Maze Solver System processes it and returns the
path, number of steps and nodes expanded. The only outside element is the maze text file.
There are no network services, so the system boundary is simple.

## 3. Container Diagram (Level 2)
[Insert docs/diagrams/c2_container.png]
- **Input Module:** reads the maze file and creates a Maze object (grid, start, goal, neighbours).
- **Search Engine:** runs BFS, DFS or A* and produces a path.
- **Heuristic Module:** gives the Manhattan distance to the goal; used only by A*.
- **Memory / Visited Set:** remembers explored cells so the search never loops.
- **Output Module:** draws the path on the maze and prints statistics.

## 4. Component Diagram (Level 3) – Search Engine
[Insert docs/diagrams/c3_component.png]
The Frontier holds nodes waiting to be explored (queue for BFS, stack for DFS, priority queue for A*).
The next node is checked by the Goal Test. If it is not the goal, it is marked in the Explored Set and its
unseen neighbours go to the Frontier. When the goal is found, the Path Reconstructor follows parent links
back to the start. Only the Search Engine is detailed because it is the core of the system.

## 5. Code Level Overview (Level 4)
- `class Node` : one search step – state, parent, cost.
- `class Maze` : the problem – grid, start, goal, `is_goal()`, `neighbors()`.
- `def parse_maze() / load_maze()` : build a Maze from text / file.
- `def bfs()` : FIFO queue; shortest path.
- `def dfs()` : LIFO stack; any path.
- `def astar()` : priority queue using f = g + h.
- `def manhattan()` : heuristic h(n).
- `def reconstruct_path()` : rebuild path from the goal node. `render()` : print result.

## 6. Design Decisions
I put each responsibility in its own module so algorithms can be swapped without touching input or output.
BFS, DFS and A* share the same Node, Maze and Heuristic classes, which makes comparison fair. The explored
set prevents infinite loops. Manhattan distance is used because moves are 4-directional, so it never
overestimates and A* stays optimal. I kept the design to 5 containers to keep it readable.

## 7. AI Contribution Note
- AI tools used: ____________ (e.g., Claude)
- What AI helped with: ____________ (e.g., explaining C4, draft code/diagrams/text)
- What I did myself: ____________ (e.g., ran the code, redrew diagrams, rewrote text, tested mazes)

## 8. Conclusion
C4 showed me that the same system can be explained at different zoom levels for different audiences.
Splitting the solver into containers made it easier to understand which part does what. I learned that the
frontier data structure is what makes BFS, DFS and A* different, while everything else stays the same.
A clear architecture makes a system easier to change, test and explain.
