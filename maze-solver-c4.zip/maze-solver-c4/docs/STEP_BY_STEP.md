# How to complete SLE-3 (step by step)

**Idea in one line:** SLE-1 = code, SLE-2 = performance, **SLE-3 = draw how the system is built.**
You are NOT writing new algorithms. You are drawing the same maze solver at 4 zoom levels.

## Step 0 – Understand C4 (15 min)
Think of Google Maps: country → city → street → house. C4 does the same for software.
| Level | Zoom | Question it answers |
| --- | --- | --- |
| 1 Context | whole world | Who uses my system? What is outside it? |
| 2 Container | big parts | What are the main blocks inside? |
| 3 Component | inside ONE block | What is inside the Search Engine? |
| 4 Code | actual code | Which classes/functions exist? |

"Container" here does NOT mean Docker. It means a major building block (module).

## Step 1 – Pick the system (2 min)
Use the **Maze Solver (BFS/DFS/A\*)**. If you already have SLE-1/SLE-2 code, use yours and
rename the boxes in the diagrams to match your own files. Otherwise use this repo's code.

## Step 2 – Run the code once (10 min)
`PYTHONPATH=src python -m maze_solver.main mazes/maze1.txt`
You must be able to say what comes in (maze file) and what goes out (path + steps).

## Step 3 – Create your GitHub repository (10 min)
1. Create account at github.com → New repository → name `maze-solver-c4` → Public → no template.
2. In the project folder:
```bash
git init
git add .
git commit -m "SLE-3: maze solver with full C4 architecture"
git branch -M main
git remote add origin https://github.com/<your-username>/maze-solver-c4.git
git push -u origin main
```
3. Put the repo link in the "GitHub / Portfolio Link" line of your report.
(Optional second repo: if your SLE-1 / SLE-2 are separate, keep them as separate repos and mention them.)

## Step 4 – Draw the diagrams yourself (45–60 min)
The guideline says *do not copy diagrams from the internet*, so redraw them in **draw.io**
(app.diagrams.net, free). Use `docs/diagrams/*.png` as your reference, but draw them in
your own style and with your own file/function names.
- **L1 Context:** 3 boxes – User, Maze Solver System, Maze File. 3 arrows.
- **L2 Container:** 5 boxes – Input, Search Engine, Heuristic, Memory/Visited, Output.
- **L3 Component:** only inside Search Engine – Frontier, Explored, Goal Test, Path Reconstructor.
- **L4 Code:** list of classes/functions (or small class diagram).
Every box = name + one line of what it does. Every arrow = a label. Export as PNG.

## Step 5 – Write the report (45 min)
Open `docs/SLE3_report_draft.md`, rewrite each section in your own words, fill PRN/Name/Division/Date.
Use the exact headings 1–8 from the guideline. 2–3 pages, max 4.

## Step 6 – AI note (5 min)
Be honest. Example: "I used Claude to understand C4 and get a starting draft of the diagrams and text.
I ran the code, redrew the diagrams in draw.io, and rewrote explanations myself."

## Step 7 – Check and submit (10 min)
File name `SLE3_PRN_YourName.docx` (or .pdf) → tick the checklist in the guideline → upload on Moodle SLE-3.

## Step 8 – Prepare for the oral (30 min)
Read `docs/ORAL_PREP.md` twice. Practice saying the 60-second summary aloud. Open your diagrams and
trace one request from User to Output using your finger.
