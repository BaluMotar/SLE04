# Oral / Viva Preparation – SLE-3 (C4 Model)

## 60-second summary (memorize this)
"My system is a Maze Solver that finds a path using BFS, DFS and A*. I described it with the C4 model.
Level 1, Context: the user gives a maze file and gets a path back. Level 2, Containers: Input, Search Engine,
Heuristic, Memory (visited set) and Output. Level 3, Components of the Search Engine: Frontier, Explored set,
Goal test and Path reconstructor. Level 4, Code: Node, Maze, bfs, dfs, astar, manhattan and reconstruct_path.
I kept each part separate so I can change an algorithm without touching input or output."

## Basics
**Q1. What is the C4 model?** A way to show software architecture at four zoom levels: Context, Container,
Component, Code – from big picture to details.

**Q2. Why four levels?** Different people need different detail. A user needs level 1, a developer needs level 3–4.

**Q3. What is a "container" in C4? Is it Docker?** No. It is a major block that runs or stores something –
here, a module such as the Search Engine.

**Q4. Difference between container and component?** Container = big block in the system. Component = a smaller
part inside one container.

**Q5. Why only one container at Level 3?** The guideline asks for one; I chose the Search Engine because it is
the core of the system.

**Q6. What is in your Context diagram?** User, Maze Solver System, maze file. Arrows: maze + algorithm in, path out.

**Q7. Why is the Search Engine your most important container?** All the AI logic (BFS/DFS/A*) lives there.

## Search / AI concepts
**Q8. What is the frontier (open list)?** Nodes discovered but not yet explored.

**Q9. What is the explored (closed) set and why needed?** Cells already visited; prevents loops and repeated work.

**Q10. How do BFS, DFS and A* differ?**
- BFS: queue (FIFO); explores level by level; shortest path when every step costs 1.
- DFS: stack (LIFO); goes deep first; finds a path, not always the shortest; uses less memory.
- A*: priority queue by f(n) = g(n) + h(n); shortest path if h is admissible; usually expands fewer nodes.

**Q11. What is a heuristic? Which did you use?** An estimate of remaining cost to the goal. Manhattan distance:
|row diff| + |col diff|.

**Q12. Why is Manhattan distance admissible here?** Moves are up/down/left/right with cost 1, so the true cost is
never less than Manhattan distance – it never overestimates.

**Q13. What are g(n), h(n), f(n)?** g = cost so far, h = estimated cost to goal, f = g + h.

**Q14. How do you get the final path?** Every Node stores its parent. From the goal, follow parents back to the
start and reverse the list (`reconstruct_path`).

**Q15. What if there is no path?** The frontier empties and the function returns `None`; Output prints "No path found".

**Q16. Is BFS optimal? Is DFS?** BFS yes (equal step cost); DFS no.

**Q17. Time complexity?** BFS/DFS O(V+E) on a grid, O(rows × cols). A* depends on the heuristic; with a good h it
expands fewer nodes.

## Design questions
**Q18. Why did you split the system this way?** Separation of concerns: each module has one job, so I can swap or
test one without breaking others. Example: add Euclidean heuristic by editing only heuristic.py.

**Q19. How would you add a new algorithm (e.g., Dijkstra/Greedy)?** Add a function in the Search Engine that uses
the same Node/Maze; Input and Output stay unchanged.

**Q20. What would change for a bigger system (e.g., a web app)?** Context gets a web browser, Container level gets
a web UI and maybe an API. Context and Container change; Code level stays mostly the same.

**Q21. How is this connected to SLE-1 and SLE-2?** SLE-1 was the code, SLE-2 measured its performance, SLE-3 is
the architecture of the same system.

**Q22. Which agent type is this?** A goal-based agent that searches; environment is fully observable, deterministic,
static, discrete (good link to PEAS).

**Q23. What did you do yourself vs AI?** Answer honestly using your AI note: e.g. "AI helped me understand C4 and
gave a draft; I ran the code, redrew the diagrams, and rewrote the text. I can explain every box."

## Quick tricks for the oral
- Always trace an example: "User gives maze1.txt → Input builds Maze → Search Engine pops from Frontier → Goal Test → Output."
- If you don't know something, say what you do know and reason aloud; do not bluff.
- Be ready to point at any box and say its job in one sentence.
- Be ready to run `python -m maze_solver.main mazes/maze1.txt` live.
