import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "src"))

from maze_solver.maze_input import parse_maze
from maze_solver.search import bfs, dfs, astar

OPEN = "S..\n...\n..G"
BLOCKED = "S#G"


def test_bfs_and_astar_find_shortest():
    m = parse_maze(OPEN)
    assert len(bfs(m)[0]) - 1 == 4
    assert len(astar(m)[0]) - 1 == 4


def test_dfs_finds_a_path():
    path, _ = dfs(parse_maze(OPEN))
    assert path[0] == (0, 0) and path[-1] == (2, 2)


def test_no_path():
    for algo in (bfs, dfs, astar):
        assert algo(parse_maze(BLOCKED))[0] is None
