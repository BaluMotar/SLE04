# Maze Solver – Full C4 Architecture (SLE-3)

Course: 02AML204 – Introduction to Artificial Intelligence

A small Python maze solver (BFS, DFS, A*) built to demonstrate the **C4 model**
(Context → Container → Component → Code).

## Run it
```bash
# from the repo root (Python 3.8+, no extra libraries needed)
PYTHONPATH=src python -m maze_solver.main mazes/maze1.txt --algo all
PYTHONPATH=src python -m maze_solver.main mazes/maze2_open.txt --algo astar
```
On Windows PowerShell: `$env:PYTHONPATH="src"; python -m maze_solver.main mazes/maze1.txt`

## Maze file format
`#` wall, `.` open cell, `S` start, `G` goal.

## Folder layout
| Path | What it is |
| --- | --- |
| `src/maze_solver/` | The code (one file per container) |
| `mazes/` | Sample mazes |
| `tests/` | Small tests |
| `docs/diagrams/` | C4 diagrams (PNG + Graphviz `.dot` source) |
| `docs/SLE3_report_draft.md` | Text for the Word report |
| `docs/STEP_BY_STEP.md` | How to finish the assignment |
| `docs/ORAL_PREP.md` | Oral/viva questions and answers |

## C4 at a glance
1. **Context** – User ↔ Maze Solver System ↔ maze file
2. **Container** – Input, Search Engine, Heuristic, Memory/Visited, Output
3. **Component** (Search Engine) – Frontier, Explored set, Goal test, Path reconstructor
4. **Code** – `Node`, `Maze`, `bfs/dfs/astar`, `manhattan`, `reconstruct_path`

See `docs/diagrams/`.

## AI contribution
Fill in honestly – see the AI Contribution Note in `docs/SLE3_report_draft.md`.
