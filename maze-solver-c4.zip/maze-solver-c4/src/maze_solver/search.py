"""Container: Search Engine - BFS, DFS and A*.

Components inside (Level 3):
  Frontier / Open List, Explored / Closed Set, Goal Test, Path Reconstructor
"""
import heapq
from collections import deque
from itertools import count
from typing import List, Optional, Tuple

from .heuristic import manhattan
from .maze_input import Maze
from .node import Node, State


def reconstruct_path(node: Node) -> List[State]:
    """Component: Path Reconstructor - follow parent links back to the start."""
    path = []
    while node is not None:
        path.append(node.state)
        node = node.parent
    return path[::-1]


def bfs(maze: Maze) -> Tuple[Optional[List[State]], int]:
    """Breadth-first: FIFO queue. Shortest path (all steps cost 1)."""
    frontier = deque([Node(maze.start)])      # Frontier
    explored = {maze.start}                   # Explored set (visited)
    expanded = 0
    while frontier:
        node = frontier.popleft()
        expanded += 1
        if maze.is_goal(node.state):          # Goal Test
            return reconstruct_path(node), expanded
        for nxt in maze.neighbors(node.state):
            if nxt not in explored:
                explored.add(nxt)
                frontier.append(Node(nxt, node, node.cost + 1))
    return None, expanded


def dfs(maze: Maze) -> Tuple[Optional[List[State]], int]:
    """Depth-first: LIFO stack. Finds *a* path, not always the shortest."""
    frontier = [Node(maze.start)]
    explored = set()
    expanded = 0
    while frontier:
        node = frontier.pop()
        if node.state in explored:
            continue
        explored.add(node.state)
        expanded += 1
        if maze.is_goal(node.state):
            return reconstruct_path(node), expanded
        for nxt in maze.neighbors(node.state):
            if nxt not in explored:
                frontier.append(Node(nxt, node, node.cost + 1))
    return None, expanded


def astar(maze: Maze) -> Tuple[Optional[List[State]], int]:
    """A*: priority queue ordered by f(n) = g(n) + h(n). Shortest path, fewer nodes."""
    tie = count()                              # breaks ties in the heap
    start = Node(maze.start)
    frontier = [(manhattan(maze.start, maze.goal), next(tie), start)]
    best_cost = {maze.start: 0}                # Explored/Closed info
    expanded = 0
    while frontier:
        _, _, node = heapq.heappop(frontier)
        if node.cost > best_cost.get(node.state, float("inf")):
            continue                           # stale entry
        expanded += 1
        if maze.is_goal(node.state):
            return reconstruct_path(node), expanded
        for nxt in maze.neighbors(node.state):
            g = node.cost + 1
            if g < best_cost.get(nxt, float("inf")):
                best_cost[nxt] = g
                f = g + manhattan(nxt, maze.goal)
                heapq.heappush(frontier, (f, next(tie), Node(nxt, node, g)))
    return None, expanded


ALGORITHMS = {"bfs": bfs, "dfs": dfs, "astar": astar}
