"""Container: Output Module - shows the final path and statistics."""
from typing import List, Optional
from .maze_input import Maze
from .node import State


def render(maze: Maze, path: Optional[List[State]]) -> str:
    """Return the maze as text with the path drawn using '*'."""
    cells = {p for p in (path or []) if p not in (maze.start, maze.goal)}
    lines = []
    for r, row in enumerate(maze.grid):
        lines.append("".join("*" if (r, c) in cells else ch
                             for c, ch in enumerate(row)))
    return "\n".join(lines)


def report(name: str, maze: Maze, path, expanded: int) -> str:
    if path is None:
        return f"[{name}] No path found. Nodes expanded: {expanded}"
    return (f"[{name}] Path length: {len(path) - 1} steps | "
            f"Nodes expanded: {expanded}\n{render(maze, path)}")
