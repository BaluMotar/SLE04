"""Container: Input Module - reads a maze from text and builds a Maze object."""
from typing import List
from .node import State


class Maze:
    """Problem definition: grid + start + goal + legal moves."""

    def __init__(self, grid: List[str], start: State, goal: State):
        self.grid, self.start, self.goal = grid, start, goal

    def is_goal(self, state: State) -> bool:
        return state == self.goal

    def neighbors(self, state: State) -> List[State]:
        """Up, down, left, right cells that are inside the grid and not walls."""
        r, c = state
        result = []
        for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1)):
            nr, nc = r + dr, c + dc
            if 0 <= nr < len(self.grid) and 0 <= nc < len(self.grid[0]) \
                    and self.grid[nr][nc] != "#":
                result.append((nr, nc))
        return result


def parse_maze(text: str) -> Maze:
    """'#' wall, '.' open, 'S' start, 'G' goal."""
    grid = [line for line in text.strip("\n").splitlines()]
    start = goal = None
    for r, row in enumerate(grid):
        for c, ch in enumerate(row):
            if ch == "S":
                start = (r, c)
            elif ch == "G":
                goal = (r, c)
    if start is None or goal is None:
        raise ValueError("Maze must contain one 'S' and one 'G'")
    return Maze(grid, start, goal)


def load_maze(path: str) -> Maze:
    with open(path, encoding="utf-8") as f:
        return parse_maze(f.read())
