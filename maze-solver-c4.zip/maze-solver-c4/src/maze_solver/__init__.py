"""Maze Solver - SLE-3 (C4 architecture demo) for 02AML204."""
