"""Entry point (the 'User' talks to the system here).

Usage:  python -m maze_solver.main mazes/maze1.txt --algo astar
"""
import argparse
from .maze_input import load_maze
from .output import report
from .search import ALGORITHMS


def main() -> None:
    parser = argparse.ArgumentParser(description="Maze Solver (BFS / DFS / A*)")
    parser.add_argument("maze_file")
    parser.add_argument("--algo", choices=[*ALGORITHMS, "all"], default="all")
    args = parser.parse_args()

    maze = load_maze(args.maze_file)
    names = ALGORITHMS if args.algo == "all" else [args.algo]
    for name in names:
        path, expanded = ALGORITHMS[name](maze)
        print(report(name.upper(), maze, path, expanded), end="\n\n")


if __name__ == "__main__":
    main()
