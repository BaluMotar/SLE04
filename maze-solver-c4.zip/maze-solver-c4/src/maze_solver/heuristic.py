"""Container: Heuristic Module - estimates distance to the goal (used by A*)."""
from .node import State


def manhattan(a: State, b: State) -> int:
    """|row difference| + |column difference|. Admissible on a 4-direction grid."""
    return abs(a[0] - b[0]) + abs(a[1] - b[1])
