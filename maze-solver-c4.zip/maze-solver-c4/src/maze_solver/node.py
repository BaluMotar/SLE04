"""Level-4 code: Node - one step on a search path."""
from dataclasses import dataclass
from typing import Optional, Tuple

State = Tuple[int, int]  # (row, col)


@dataclass
class Node:
    state: State                    # where we are in the maze
    parent: Optional["Node"] = None  # how we got here (used to rebuild the path)
    cost: int = 0                   # g(n): steps taken from the start
